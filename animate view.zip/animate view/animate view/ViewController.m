//
//  ViewController.m
//  animate view
//
//  Created by MAC OS on 1/26/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    //UIImageView *img;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    tap=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handle:)];
    
    
    
    v1=[[UIView alloc]initWithFrame:CGRectMake(50, 100, 200, 200)];
    
    
    v1.backgroundColor=[UIColor grayColor];
    v1.layer.cornerRadius=26;
    v1.clipsToBounds=YES;
    
    
    
    UIImageView *image1 = [[UIImageView alloc] initWithFrame:v1.bounds];
    
    [v1 addSubview:image1];
    UIImage *img1 = [UIImage imageNamed:@"cake.jpg"];
    image1.image = img1;

    [self.view addSubview:v1];
    
    [v1 addGestureRecognizer:tap];
    
   
    
    
}

-(void)handle:(UIPanGestureRecognizer *)sender
{
    
    CGPoint  point  = [sender locationInView:self.view];
    
    v1.center = point;
    
    
    if (sender.state == UIGestureRecognizerStateEnded) {
        
        
        time = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(handle1:) userInfo:nil repeats:YES];
        

    
    }
    
    
    


    
}
-(void)handle1:(NSTimer *)sender
{
     static int ox =100,oy=100;
    if (ox<=200 && oy<=400) {
        
    
    
   
    ox+=5; 
    oy+=20;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    v1.frame=CGRectMake(ox,oy, 190, 180);
    
    
    [UIView commitAnimations];

    }
    else
    {
        [time invalidate];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        v1.frame=CGRectMake(50, 100, 200, 200);
        
        
        [UIView commitAnimations];

        
        
    }
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
