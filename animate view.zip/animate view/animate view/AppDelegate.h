//
//  AppDelegate.h
//  animate view
//
//  Created by MAC OS on 1/26/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

